package basic;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class SalesScreen {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(SalesScreen::createAndShowGUI);
    }

    public static void createAndShowGUI() {
        // 메인 프레임 설정
        JFrame frame = new JFrame("햄버거 가게 POS");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLayout(new BorderLayout());

        // 메뉴 데이터 설정
        String[][] menuData = {
                {"햄버거1", "버거", "5000"},
                {"햄버거2", "버거", "5500"},
                {"감자튀김", "사이드", "2000"},
                {"콜라", "음료", "1500"},
                {"사이다", "음료", "1500"}
        };
        String[] menuColumns = {"메뉴명", "종류", "가격"};

        // 메뉴 테이블 생성
        DefaultTableModel menuModel = new DefaultTableModel(menuData, menuColumns);
        JTable menuTable = new JTable(menuModel);
        JScrollPane menuScrollPane = new JScrollPane(menuTable);

        // 주문 테이블 생성
        String[] orderColumns = {"메뉴명", "수량", "가격"};
        DefaultTableModel orderModel = new DefaultTableModel(orderColumns, 0);
        JTable orderTable = new JTable(orderModel);
        JScrollPane orderScrollPane = new JScrollPane(orderTable);

        // 계산 영역
        JPanel bottomPanel = new JPanel(new GridLayout(3, 2));
        JLabel totalLabel = new JLabel("총 판매액:");
        JTextField totalField = new JTextField("0");
        totalField.setEditable(false);
        JButton calculateButton = new JButton("계산");
        JButton resetButton = new JButton("초기화");

        bottomPanel.add(totalLabel);
        bottomPanel.add(totalField);
        bottomPanel.add(calculateButton);
        bottomPanel.add(resetButton);

        // 이벤트 리스너 추가
        menuTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && menuTable.getSelectedRow() != -1) {
                String selectedMenu = (String) menuModel.getValueAt(menuTable.getSelectedRow(), 0);
                String selectedPrice = (String) menuModel.getValueAt(menuTable.getSelectedRow(), 2);

                // 주문 추가 대화상자
                String quantityStr = JOptionPane.showInputDialog(frame, "수량을 입력하세요:", "수량 입력", JOptionPane.PLAIN_MESSAGE);
                if (quantityStr != null && !quantityStr.isEmpty()) {
                    int quantity = Integer.parseInt(quantityStr);
                    int totalPrice = quantity * Integer.parseInt(selectedPrice);
                    orderModel.addRow(new Object[]{selectedMenu, quantity, totalPrice});
                }
            }
        });

        calculateButton.addActionListener(e -> {
            int total = 0;
            for (int i = 0; i < orderModel.getRowCount(); i++) {
                total += (int) orderModel.getValueAt(i, 2);
            }
            totalField.setText(String.valueOf(total));
        });

        resetButton.addActionListener(e -> {
            orderModel.setRowCount(0);
            totalField.setText("0");
        });

        // 레이아웃 구성
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, menuScrollPane, orderScrollPane);
        splitPane.setDividerLocation(500);

        frame.add(splitPane, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        // 프레임 표시
        frame.setVisible(true);
    }
}