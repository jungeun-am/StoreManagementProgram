package basic;
import javax.swing.*;
import java.awt.event.*;

public class ComboBoxWithMenuExample {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("ComboBox with Submenu Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // ComboBox 만들기
            JComboBox<String> comboBox = new JComboBox<>(new String[]{"Option 1", "Option 2", "Option 3"});

            // ComboBox 클릭 시 메뉴 띄우기
            comboBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JMenu menu = new JMenu("Submenu");
                    JMenuItem item1 = new JMenuItem("Submenu Item 1");
                    JMenuItem item2 = new JMenuItem("Submenu Item 2");
                    menu.add(item1);
                    menu.add(item2);

                    JPopupMenu popupMenu = new JPopupMenu();
                    popupMenu.add(menu);
                    popupMenu.show(comboBox, 0, comboBox.getHeight());
                }
            });

            frame.add(comboBox);
            frame.setSize(400, 200);
            frame.setVisible(true);
        });
    }
}
