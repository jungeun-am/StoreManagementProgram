package Jae;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class MaterialManager extends JFrame {
    private JPanel mainPanel;
    private JPanel inputPanel;
    private JPanel resultPanel;

    private JComboBox<String> categoryBox;
    private JTextField materialField;
    private JTextField quantityField;
    private JTextField priceField;
    private JButton addButton;

    private JTextArea resultArea;

    public MaterialManager() {
        // 프레임 설정
        setTitle("재료 관리 시스템");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        // 메인 패널
        mainPanel = new JPanel(new BorderLayout());

        // 입력 패널 생성
        inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("재료 입력"));

        // 입력 필드 구성
        categoryBox = new JComboBox<>(new String[]{"1", "2", "3", "4"});
        materialField = new JTextField();
        quantityField = new JTextField();
        priceField = new JTextField();
        addButton = new JButton("추가");

        inputPanel.add(createLabeledField("카테고리", categoryBox));
        inputPanel.add(createLabeledField("재료명", materialField));
        inputPanel.add(createLabeledField("수량", quantityField));
        inputPanel.add(createLabeledField("단가", priceField));
        inputPanel.add(new JLabel()); // 빈 공간
        inputPanel.add(addButton);

        // 결과 패널 생성
        resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBorder(BorderFactory.createTitledBorder("결과 표시"));
        resultArea = new JTextArea();
        resultArea.setEditable(false); // 결과는 읽기 전용
        resultPanel.add(new JScrollPane(resultArea), BorderLayout.CENTER);

        // 메인 패널에 입력 및 결과 패널 배치
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(resultPanel, BorderLayout.CENTER);

        // 프레임에 메인 패널 추가
        add(mainPanel);

        // 버튼 이벤트 추가
        addButton.addActionListener(e -> addMaterial());

        setVisible(true);
    }

    private JPanel createLabeledField(String labelText, JComponent inputField) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel(labelText);
        panel.add(label, BorderLayout.WEST);
        panel.add(inputField, BorderLayout.CENTER);
        return panel;
    }

    private void addMaterial() {
        // 입력된 값 가져오기
        String category = (String) categoryBox.getSelectedItem();
        String materialName = materialField.getText();
        String quantity = quantityField.getText();
        String price = priceField.getText();

        // 유효성 검사 (단순 예시)
        if (materialName.isEmpty() || quantity.isEmpty() || price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "모든 필드를 입력해주세요.", "입력 오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int quantityValue = Integer.parseInt(quantity);
            double priceValue = Double.parseDouble(price);

            // 결과 표시
            resultArea.append("카테고리: " + category + ", 재료명: " + materialName +
                    ", 수량: " + quantityValue + ", 단가: " + priceValue + "\n");

            // 입력 필드 초기화
            materialField.setText("");
            quantityField.setText("");
            priceField.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "수량과 단가는 숫자로 입력해주세요.", "입력 오류", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MaterialManager::new);
    }
}
