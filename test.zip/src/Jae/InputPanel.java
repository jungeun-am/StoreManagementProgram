package Jae;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class InputPanel {
    private JPanel panel;
    private JComboBox<String> categoryBox;
    private JTextField materialField;
    private JTextField quantityField;
    private JTextField priceField;
    private JButton addButton;

    public InputPanel() {
        panel = new JPanel(new GridLayout(5, 2, 10, 10)); // GridLayout 사용

        // 카테고리 선택
        categoryBox = new JComboBox<>(new String[]{"1", "2", "3", "4"});
        materialField = new JTextField();
        quantityField = new JTextField();
        priceField = new JTextField();
        addButton = new JButton("추가");

        // 입력 필드 추가
        panel.add(createLabeledField("카테고리", categoryBox));
        panel.add(createLabeledField("재료명", materialField));
        panel.add(createLabeledField("수량", quantityField));
        panel.add(createLabeledField("단가", priceField));

        // 추가 버튼
        panel.add(new JLabel());  // 빈 레이블 (위치 맞추기)
        panel.add(addButton);
    }

    // 패널을 반환하는 메서드
    public JPanel getPanel() {
        return panel;
    }

    // JLabel과 JTextField (또는 JComboBox)를 묶어서 반환하는 메서드
    private JPanel createLabeledField(String labelText, JComponent component) {
        JPanel fieldPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel label = new JLabel(labelText);
        fieldPanel.add(label);
        fieldPanel.add(component);
        return fieldPanel;
    }

    // "추가" 버튼의 액션 리스너 설정
    public void setAddButtonListener(ActionListener listener) {
        addButton.addActionListener(listener);
    }
}
