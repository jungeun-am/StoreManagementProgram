package Jae;

import java.awt.BorderLayout;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Jae.MaterialData;

public class DatePanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public DatePanel() {
        // 테이블 모델 생성 (열 이름 설정)
        tableModel = new DefaultTableModel(new String[] {"카테고리", "재료 이름", "수량", "가격"}, 0);
        // 테이블 객체 생성
        table = new JTable(tableModel);
    }

    // MaterialData 객체를 받아 테이블에 새로운 행 추가
    public void addRow(MaterialData materialData) {
        tableModel.addRow(new Object[] {
            materialData.getCategory(),
            materialData.getMaterialName(),
            materialData.getQuantity(),
            materialData.getPrice()
        });
    }

    // 테이블을 포함한 JPanel 반환
    public JPanel getPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        // JScrollPane을 사용해 테이블을 스크롤 가능하게 만들어줌
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }
}
