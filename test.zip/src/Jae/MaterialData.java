package Jae;

public class MaterialData {
    private String category;
    private String materialName;
    private String quantity;
    private String price;

    public MaterialData(String category, String materialName, String quantity, String price) {
        this.category = category;
        this.materialName = materialName;
        this.quantity = quantity;
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public String getMaterialName() {
        return materialName;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getPrice() {
        return price;
    }
}