package Jae;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TablePanel {
    private JPanel panel;
    private JTable table;
    private DefaultTableModel tableModel;

    public TablePanel() {
        panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("재료 목록"));

        // 테이블 모델 설정
        String[] columnNames = {"카테고리", "재료명", "수량", "단가"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        // 테이블 추가
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
    }

    public void addRow(MaterialData data) {
        tableModel.addRow(new Object[]{data.getCategory(), data.getMaterialName(), data.getQuantity(), data.getPrice()});
    }

    public JPanel getPanel() {
        return panel;
    }
}