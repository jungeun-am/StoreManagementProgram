package test;
import javax.swing.*;
import java.awt.*;

public class ReportPanel extends JPanel {
    public ReportPanel() {
        setLayout(new BorderLayout());

        // JTabbedPane 생성
        JTabbedPane tabbedPane = new JTabbedPane();

        // 각 탭 추가
        tabbedPane.addTab("매출", createDefaultPanel("매출"));
        tabbedPane.addTab("재고 주문", createDefaultPanel("재고 주문"));
        tabbedPane.addTab("직원", createDefaultPanel("직원"));
        tabbedPane.addTab("손익계산", createProfitTab());

        add(tabbedPane, BorderLayout.CENTER);
    }

    // 기본 패널 생성 (매출, 재고 주문, 직원용)
    private JPanel createDefaultPanel(String title) {
        JPanel panel = new JPanel();
        panel.add(new JLabel(title + " 탭 내용"));
        return panel;
    }

    // 손익계산 탭 생성
    private JPanel createProfitTab() {
        // 날짜 입력과 조회 버튼을 담당하는 DatePanel을 생성
        DatePanel datePanel = new DatePanel();

        // 손익계산서 상세 정보를 보여주는 ProfitDetailPanel을 생성
        ProfitDetailPanel detailPanel = new ProfitDetailPanel();

        // 조회 버튼에 검색 로직 추가
        ProfitSearchHandler searchHandler = new ProfitSearchHandler(datePanel, detailPanel);
        datePanel.addSearchButtonListener(e -> searchHandler.handleSearch());

        // 상단과 상세 정보 추가
        JPanel profitPanel = new JPanel(new BorderLayout(10, 10));
        profitPanel.add(datePanel, BorderLayout.NORTH);
        profitPanel.add(detailPanel, BorderLayout.CENTER);

        return profitPanel;
    }
}
