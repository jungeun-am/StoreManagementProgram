package test;
import javax.swing.*;
import java.awt.*;

public class ProfitDetailPanel extends JPanel {
    private JTextField profitIdField, reportDateField, totalSalesField, totalCostField, netProfitField;

    public ProfitDetailPanel() {
        setLayout(new GridLayout(5, 2, 10, 10));
        setBorder(BorderFactory.createTitledBorder("손익계산 상세"));

        profitIdField = createDetailField("손익계산서 ID:");
        reportDateField = createDetailField("보고서 작성일:");
        totalSalesField = createDetailField("총 매출:");
        totalCostField = createDetailField("총 비용:");
        netProfitField = createDetailField("순이익:");
    }

    private JTextField createDetailField(String label) {
        add(new JLabel(label));
        JTextField textField = new JTextField();
        textField.setEditable(false);  // 읽기 전용 필드
        add(textField);
        return textField;
    }

    public void setProfitDetails(String profitId, String reportDate, String totalSales, String totalCost, String netProfit) {
        profitIdField.setText(profitId);
        reportDateField.setText(reportDate);
        totalSalesField.setText(totalSales);
        totalCostField.setText(totalCost);
        netProfitField.setText(netProfit);
    }
}
