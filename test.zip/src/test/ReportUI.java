package test;
import javax.swing.*;
import java.awt.*;

public class ReportUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("보고서 화면");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1000, 600);
            frame.setLocationRelativeTo(null);
            frame.setContentPane(new ReportPanel());
            frame.setVisible(true);
        });
    }
}
