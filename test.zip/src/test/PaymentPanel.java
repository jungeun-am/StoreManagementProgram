package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
// PaymentPanel 클래스: 결제 로직을 처리하고, 금액 계산 및 결과를 보여줍니다.
public class PaymentPanel extends JPanel {
    private final ItemListPanel itemListPanel;
    private JTextField discountField, receivedAmountField, changeField;

    public PaymentPanel(ItemListPanel itemListPanel) {
        this.itemListPanel = itemListPanel;
        setLayout(new GridLayout(4, 2, 5, 5));

        JLabel discountLabel = new JLabel("할인:");
        discountField = new JTextField(10);
        add(discountLabel);
        add(discountField);

        JLabel receivedAmountLabel = new JLabel("받은 금액:");
        receivedAmountField = new JTextField(10);
        add(receivedAmountLabel);
        add(receivedAmountField);

        JLabel changeLabel = new JLabel("잔돈:");
        changeField = new JTextField(10);
        changeField.setEditable(false);
        add(changeLabel);
        add(changeField);

        JButton payButton = new JButton("결제");
        payButton.addActionListener(e -> processPayment());
        add(payButton);
    }

    private void processPayment() {
        try {
            int total = itemListPanel.getTotalAmount();
            int discount = Integer.parseInt(discountField.getText());
            int received = Integer.parseInt(receivedAmountField.getText());
            int change = received - (total - discount);

            if (change >= 0) {
                changeField.setText(String.valueOf(change));
                JOptionPane.showMessageDialog(this, "결제가 완료되었습니다!");
            } else {
                JOptionPane.showMessageDialog(this, "금액이 부족합니다!", "오류", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "입력을 확인해주세요!", "오류", JOptionPane.ERROR_MESSAGE);
        }
    }
}
