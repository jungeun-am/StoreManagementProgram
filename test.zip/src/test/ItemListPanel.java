package test;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

// 상품 리스트와 수량을 관리하는 패널
public class ItemListPanel extends JPanel {
    private final DefaultListModel<String> itemListModel;
    private List<Item> items;  // 아이템 리스트
    private int selectedItemIndex = -1;  // 선택된 아이템 인덱스

    public ItemListPanel() {
        setLayout(new BorderLayout(10, 10));

        itemListModel = new DefaultListModel<>();
        JList<String> itemList = new JList<>(itemListModel);
        JScrollPane itemScrollPane = new JScrollPane(itemList);
        add(itemScrollPane, BorderLayout.CENTER);

        // 예시 아이템들
        items = new ArrayList<>();
        items.add(new Item("치즈버거", 5000, 1));  // 초기 데이터
        items.add(new Item("불고기버거", 5000, 1));
        items.add(new Item("사이드 감자튀김", 2000, 1));

        // 아이템 목록 초기화
        updateItemList();

        // 아이템 선택 이벤트
        itemList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectedItemIndex = itemList.getSelectedIndex();  // 선택된 아이템 인덱스 저장
            }
        });
    }

    // 아이템 목록을 업데이트
    private void updateItemList() {
        itemListModel.clear();
        for (Item item : items) {
            itemListModel.addElement(item.toString());  // 각 아이템의 문자열을 추가
        }
    }

    // 선택된 아이템의 수량을 업데이트
    public void updateSelectedItemQuantity(int quantity) {
        // 선택된 아이템 가져오기
        Item selectedItem = getSelectedItem();
        if (selectedItem != null) {
            selectedItem.setQuantity(quantity);
            // 업데이트 후 UI 갱신
            refreshUI();
        } else {
            System.out.println("선택된 아이템이 없습니다.");
        }
    }


    private Item getSelectedItem() {
		// TODO Auto-generated method stub
		return null;
	}

	private void refreshUI() {
		// TODO Auto-generated method stub
		
	}


	// 아이템 클래스: 이름, 가격, 수량을 관리
    private static class Item {
        private String name;
        private int price;
        private int quantity;

        public Item(String name, int price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        @Override
        public String toString() {
            return name + " - " + quantity + "개 - " + price + "원";  // 아이템 정보 출력
        }
    }

	public int getTotalAmount() {
		// TODO Auto-generated method stub
		return 0;
	}
}
