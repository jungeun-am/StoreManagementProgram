package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class test extends JFrame {
    // UI 구성 요소 선언
    private JTextField idField, nameField, phoneField;
    private JPasswordField passwordField;
    private JComboBox<String> groupComboBox;
    
    // 기본 생성자
    public test() {
        setTitle("직원 등록");
        setSize(585, 653);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setFont(new Font("돋움", Font.BOLD, 14));
        
        // 메인 레이아웃 설정
        getContentPane().setLayout(new BorderLayout());

        // JPanel을 각각 나누어 레이아웃을 정리
        JPanel inputPanel = createInputPanel();
        JPanel buttonPanel = createButtonPanel();
        
        // Panel을 JFrame에 추가
        getContentPane().add(inputPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // 입력 항목을 위한 패널 생성
    private JPanel createInputPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null); // 레이아웃 없이 좌표로 위치 지정

        // 아이디
        JLabel idLabel = new JLabel("아이디:");
        idLabel.setBounds(48, 61, 157, 52);
        idLabel.setFont(new Font("돋움", Font.BOLD, 14));
        idField = new JTextField(20);
        idField.setBounds(146, 73, 223, 29);
        
        // 비밀번호
        JLabel passwordLabel = new JLabel("비밀번호:");
        passwordLabel.setBounds(48, 112, 157, 52);
        passwordLabel.setFont(new Font("돋움", Font.BOLD, 14));
        passwordField = new JPasswordField(20);
        passwordField.setBounds(146, 122, 223, 29);
        
        // 직원 이름
        JLabel nameLabel = new JLabel("직원 이름:");
        nameLabel.setBounds(48, 174, 157, 52);
        nameLabel.setFont(new Font("돋움", Font.BOLD, 14));
        nameField = new JTextField(20);
        nameField.setBounds(146, 190, 223, 29);
   
        
        // 전화번호
        JLabel phoneLabel = new JLabel("전화번호:");
        phoneLabel.setBounds(48, 248, 185, 52);
        phoneLabel.setFont(new Font("돋움", Font.BOLD, 14));
        phoneField = new JTextField(20);
        phoneField.setBounds(146, 260, 223, 29);
        
        // 그룹 선택 ComboBox
        JLabel groupLabel = new JLabel("직급");
        groupLabel.setBounds(48, 310, 185, 52);
        groupLabel.setFont(new Font("돋움", Font.BOLD, 14));
        String[] groups = { "크루", "팀리더", "매니저" };
        groupComboBox = new JComboBox<>(groups);
        groupComboBox.setModel(new DefaultComboBoxModel(new String[] {"크루", "팀 리더", "매니저"}));
        groupComboBox.setBounds(146, 322, 223, 29);
        
        // 컴포넌트를 panel에 추가
        panel.add(idLabel);
        panel.add(idField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(groupLabel);
        panel.add(groupComboBox);
        
        // 아이디 중복 확인 버튼
        JButton checkIdButton = new JButton("아이디 중복 확인");
        checkIdButton.setBounds(381, 76, 127, 23);
        panel.add(checkIdButton);
        checkIdButton.setFont(new Font("굴림", Font.BOLD, 12));
        checkIdButton.addActionListener(e -> checkIdDuplicate());

        return panel;
    }

    // 버튼들을 위한 패널 생성
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER));

        // 회원가입 버튼
        JButton signUpButton = new JButton("회원가입 완료");
        signUpButton.addActionListener(e -> signUp());
        panel.add(signUpButton);

        return panel;
    }

    // 아이디 중복 확인 메서드
    private void checkIdDuplicate() {
        String employeeIdValue = idField.getText().trim(); // 입력된 아이디 값 (공백 제거)

        if (employeeIdValue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "아이디를 입력해 주세요.", "아이디 입력 오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 아이디 중복 확인
        if (isIdDuplicate(employeeIdValue)) {
            JOptionPane.showMessageDialog(this, "아이디가 이미 존재합니다.", "중복 확인", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "사용 가능한 아이디입니다.", "중복 확인", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // 회원가입 처리 메서드
    private void signUp() {
        // 입력된 값 가져오기
        String employeeIdValue = idField.getText();
        String employeePassword = new String(passwordField.getPassword());
        String employeeName = nameField.getText();
        String employeePhone = phoneField.getText();
        String selectedGroup = (String) groupComboBox.getSelectedItem();

        // 그룹 ID와 직책 ID 매핑
        int groupId = getGroupId(selectedGroup);

        // DB에 데이터 삽입
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "basic", "1234")) {
            String insertSql = "INSERT INTO employees (employee_name, employee_phone, group_id, position_id, employee_id_value, employee_password) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, employeeName);
                pstmt.setString(2, employeePhone);
                pstmt.setInt(3, groupId);
                pstmt.setString(4, employeeIdValue);
                pstmt.setString(5, employeePassword);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "회원가입 성공!");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB 연결 오류: " + ex.getMessage());
        }
    }

    // 그룹 이름에 맞는 그룹 ID 반환
    private static int getGroupId(String group) {
        switch (group) {
            case "크루":
                return 1;
            case "팀리더":
                return 2;
            case "매니저":
                return 3;
            default:
                return 0;
        }
    }

    // 아이디 중복 체크 메서드
    private static boolean isIdDuplicate(String employeeIdValue) {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "basic", "1234")) {
            String checkSql = "SELECT COUNT(*) FROM employees WHERE employee_id_value = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setString(1, employeeIdValue);
                ResultSet rs = pstmt.executeQuery();
                return rs.next() && rs.getInt(1) > 0; // 아이디가 존재하면 true 반환
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "DB 연결 오류: " + e.getMessage());
            e.printStackTrace();
        }
        return false;  // 아이디가 없으면 false 반환
    }

    // 메인 메서드
    public static void main(String[] args) {
        new test();
    }
}
