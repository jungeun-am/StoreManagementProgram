package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// 수량 입력을 위한 숫자 패드를 구현
public class NumericPadPanel extends JPanel {
    private final ItemListPanel itemListPanel;  // ItemListPanel 객체를 참조
    private String currentInput = "";  // 현재 입력된 숫자(수량)

    public NumericPadPanel(ItemListPanel itemListPanel) {
        this.itemListPanel = itemListPanel;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // 숫자 패드 생성
        JPanel numericPadPanel = new JPanel(new GridLayout(4, 3, 5, 5));
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(String.valueOf(i));
            button.addActionListener(e -> handleNumericInput(e));
            numericPadPanel.add(button);
        }

        JButton button0 = new JButton("0");
        button0.addActionListener(e -> handleNumericInput(e));
        numericPadPanel.add(button0);

        // Clear 버튼: 수량 초기화
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> clearInput());
        numericPadPanel.add(clearButton);

        // Enter 버튼: 수량 적용
        JButton enterButton = new JButton("Enter");
        enterButton.addActionListener(e -> applyQuantityInput());
        numericPadPanel.add(enterButton);

        // 숫자 패드 패널을 NumericPadPanel에 추가
        add(numericPadPanel);
    }

    // 숫자 입력 처리
    private void handleNumericInput(ActionEvent e) {
        String buttonText = ((JButton) e.getSource()).getText();
        currentInput += buttonText;  // 수량 입력을 계속해서 추가
    }

    // 수량 초기화
    private void clearInput() {
        currentInput = "";  // 수량 입력을 초기화
    }

 // 수량 입력 후 적용
    private void applyQuantityInput() {
        if (!currentInput.isEmpty()) {
            try {
                int quantity = Integer.parseInt(currentInput);
                System.out.println("적용할 수량: " + quantity);  // 디버깅 로그
                itemListPanel.updateSelectedItemQuantity(quantity);  // 선택된 아이템에 수량 적용
                currentInput = "";  // 수량 입력 초기화
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "유효한 숫자를 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
