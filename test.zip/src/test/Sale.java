package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Sale extends JPanel {
    private DefaultListModel<String> itemListModel;
    private JLabel totalLabel;
    private JTextField discountField, receivedAmountField, changeField;
    private int totalAmount = 0;

    public Sale() {
        setLayout(new BorderLayout(10, 10));

        // 왼쪽과 오른쪽 레이아웃 설정
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, createLeftPanel(), createRightPanel());
        splitPane.setDividerLocation(0.5);
        splitPane.setResizeWeight(0.5);
        add(splitPane, BorderLayout.CENTER);
    }

    // 왼쪽 패널 (상품 리스트 및 계산기 표시)
    private JPanel createLeftPanel() {
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout(10, 10));

        // 상품 리스트
        itemListModel = new DefaultListModel<>();
        JList<String> itemList = new JList<>(itemListModel);
        JScrollPane itemScrollPane = new JScrollPane(itemList);
        leftPanel.add(itemScrollPane, BorderLayout.CENTER);

        // 계산기 및 결제 영역
        JPanel calcPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        JTextField totalAmountField = createInputField("총 금액:", inputPanel);
        discountField = createInputField("할인:", inputPanel);
        receivedAmountField = createInputField("받은 금액:", inputPanel);
        changeField = createInputField("잔돈:", inputPanel);
        changeField.setEditable(false); // 잔돈은 계산 결과만 표시

        calcPanel.add(inputPanel);
        leftPanel.add(calcPanel, BorderLayout.SOUTH); // 계산기 부분을 하단에 추가

        return leftPanel;
    }

    private JTextField createInputField(String label, JPanel inputPanel) {
        JLabel jLabel = new JLabel(label);
        JTextField jTextField = new JTextField(10); // 크기 10으로 JTextField 생성
        inputPanel.add(jLabel);
        inputPanel.add(jTextField);
        return jTextField;
    }

    // 오른쪽 패널 (메뉴 버튼과 수량 입력)
    private JPanel createRightPanel() {
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout(10, 10));

        // 카테고리 탭 패널
        JTabbedPane tabbedPane = new JTabbedPane();

        // 각 카테고리 탭을 추가
        tabbedPane.addTab("버거 단품", createCategoryPanel("버거 단품"));
        tabbedPane.addTab("사이드", createCategoryPanel("사이드"));
        tabbedPane.addTab("음료", createCategoryPanel("음료"));
        tabbedPane.addTab("디저트", createCategoryPanel("디저트"));

        rightPanel.add(tabbedPane, BorderLayout.CENTER); // TabbedPane을 오른쪽 패널에 추가
        rightPanel.add(createNumericPad(), BorderLayout.SOUTH);

        return rightPanel;
    }

    // 하위 메뉴를 표시하는 메서드 (카테고리 클릭 시)
    private JPanel createCategoryPanel(String category) {
        JPanel categoryPanel = new JPanel(new GridLayout(0, 3, 10, 10)); // 바둑판 형식 (3열)
        
        // 각 카테고리별 아이템을 설정
        String[] subMenuItems = MenuItems.getSubMenuItems(category);

        // 각 메뉴 아이템을 버튼으로 추가
        for (String item : subMenuItems) {
            JButton subMenuButton = new JButton(item);
            subMenuButton.addActionListener(e -> addItem(item)); // 아이템 클릭 시 주문 목록에 추가
            categoryPanel.add(subMenuButton);
        }

        return categoryPanel;
    }

    // 숫자 패드 및 결제 버튼 생성
    private JPanel createNumericPad() {
        JPanel numericPadPanel = new JPanel(new GridLayout(4, 3, 5, 5));
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(String.valueOf(i));
            button.addActionListener(e -> handleNumericInput(e));
            numericPadPanel.add(button);
        }

        JButton button0 = new JButton("0");
        button0.addActionListener(e -> handleNumericInput(e));
        numericPadPanel.add(button0);

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> clearOrderList());
        numericPadPanel.add(clearButton);

        JButton enterButton = new JButton("Enter");
        enterButton.addActionListener(e -> applyQuantityInput());
        numericPadPanel.add(enterButton);

        totalLabel = new JLabel("총 결제 금액: " + totalAmount + "원", JLabel.CENTER);
        totalLabel.setFont(new Font("맑은 고딕", Font.BOLD, 16));

        JButton payButton = new JButton("결제");
        payButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        payButton.addActionListener(e -> processPayment());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(Box.createVerticalStrut(10));
        panel.add(new JLabel("수량 입력", JLabel.CENTER));
        panel.add(numericPadPanel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(totalLabel);
        panel.add(payButton);

        return panel;
    }

    private void handleNumericInput(ActionEvent e) {
        String buttonText = ((JButton) e.getSource()).getText();
        // 숫자 입력 처리 로직 (여기서는 수량 입력을 위한 텍스트로 처리)
    }

    private void addItem(String item) {
        // 메뉴 항목의 가격을 가져옵니다.
        Map<String, Integer> menuItems = MenuItems.getSubMenuItems("버거 단품"); // 예시: "버거 단품" 카테고리
        Integer itemPrice = menuItems.get(item);
        
        if (itemPrice != null) {
            itemListModel.addElement(item + " - 1개 - " + itemPrice + "원");
            updateTotalAmount(itemPrice); // 새로운 항목 가격을 반영
        }
    }

    private void updateTotalAmount(int itemPrice) {
        totalAmount += itemPrice; // 가격을 더해줍니다.
        totalLabel.setText("총 결제 금액: " + totalAmount + "원");
    }

    // 결제 처리
    private void processPayment() {
        try {
            int total = totalAmount;
            int discount = Integer.parseInt(discountField.getText());
            int received = Integer.parseInt(receivedAmountField.getText());
            int change = received - (total - discount);

            if (change >= 0) {
                changeField.setText(String.valueOf(change));
                JOptionPane.showMessageDialog(this, "결제가 완료되었습니다!");
            } else {
                JOptionPane.showMessageDialog(this, "금액이 부족합니다!", "오류", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "입력을 확인해주세요!", "오류", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 주문 목록 초기화 (Clear 버튼)
    private void clearOrderList() {
        itemListModel.clear();
        totalAmount = 0;
        totalLabel.setText("총 결제 금액: 0원");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("판매 시스템");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        Sale salePanel = new Sale();
        frame.add(salePanel);

        frame.setVisible(true);
    }
}

// MenuItems 클래스 추가
class MenuItems {
    public static String[] getSubMenuItems(String category) {
        switch (category) {
            case "버거 단품":
                return new String[]{"치즈버거", "싸이버거", "불싸이버거"};
            case "사이드":
                return new String[]{"감자튀김", "피클", "어니언링", "너겟"};
            case "음료":
                return new String[]{"콜라", "사이다", "맥콜"};
            case "디저트":
                return new String[]{"아이스크림", "케이크", "쿠키"};
            default:
                return new String[]{};
        }
    }
}
