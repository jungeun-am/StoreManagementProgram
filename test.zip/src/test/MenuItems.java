package test;

import java.util.HashMap;
import java.util.Map;

public class MenuItems {
    private static final Map<String, String[]> categoryItemsMap = new HashMap<>();

    static {
        categoryItemsMap.put("버거 단품", new String[]{"치즈버거", "싸이버거", "불싸이버거"});
        categoryItemsMap.put("사이드", new String[]{"감자튀김", "빈 칸", "피클", "어니언링", "너겟"});
        categoryItemsMap.put("버거 세트", new String[]{"버거 세트 1", "버거 세트 2", "버거 세트 3"});
        categoryItemsMap.put("음료", new String[]{"콜라", "사이다", "맥콜"});
        categoryItemsMap.put("디저트", new String[]{"아이스크림", "케이크", "쿠키"});
    }

    public static String[] getSubMenuItems(String category) {
        return categoryItemsMap.getOrDefault(category, new String[]{});
    }
}
