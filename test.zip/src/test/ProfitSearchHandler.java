package test;
import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ProfitSearchHandler {
    private DatePanel datePanel;
    private ProfitDetailPanel detailPanel;

    public ProfitSearchHandler(DatePanel datePanel, ProfitDetailPanel detailPanel) {
        this.datePanel = datePanel;
        this.detailPanel = detailPanel;
    }

    public void handleSearch() {
        try {
            String startDateText = datePanel.getStartDateField().getText();
            String endDateText = datePanel.getEndDateField().getText();
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate startDate = LocalDate.parse(startDateText, formatter);
            LocalDate endDate = LocalDate.parse(endDateText, formatter);

            if (endDate.isBefore(startDate)) {
                JOptionPane.showMessageDialog(datePanel, "종료일은 시작일 이후여야 합니다!", "오류", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 더미 데이터 설정
            detailPanel.setProfitDetails("P12345", LocalDate.now().format(formatter), "1,000,000원", "700,000원", "300,000원");

            JOptionPane.showMessageDialog(datePanel, "조회 성공: " + startDate + " ~ " + endDate);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(datePanel, "날짜를 yyyy-MM-dd 형식으로 입력해주세요!", "오류", JOptionPane.ERROR_MESSAGE);
        }
    }
}
