package PRO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeSignUp {

    public static void main(String[] args) {
        // JFrame 생성
        JFrame frame = new JFrame("직원 등록");
        frame.getContentPane().setFont(new Font("돋움", Font.BOLD, 14));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(585, 653);

        // 직원 고유 아이디
        JLabel idLabel = new JLabel(" 아이디:");
        idLabel.setBounds(48, 10, 157, 52);
        idLabel.setFont(new Font("돋움", Font.BOLD, 14));
        JTextField idField = new JTextField(20);
        idField.setBounds(146, 22, 223, 29);

        // 비밀번호
        JLabel passwordLabel = new JLabel("비밀번호:");
        passwordLabel.setBounds(48, 61, 157, 52);
        passwordLabel.setFont(new Font("돋움", Font.BOLD, 14));
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setBounds(146, 73, 223, 29);

        // 직원 이름
        JLabel nameLabel = new JLabel("직원 이름:");
        nameLabel.setBounds(48, 123, 157, 52);
        nameLabel.setFont(new Font("돋움", Font.BOLD, 14));
        JTextField nameField = new JTextField(20);
        nameField.setBounds(146, 135, 223, 29);

        // 직원 이메일
        JLabel emailLabel = new JLabel("직원 이메일:");
        emailLabel.setBounds(48, 185, 185, 52);
        emailLabel.setFont(new Font("돋움", Font.BOLD, 14));
        JTextField emailField = new JTextField(20);
        emailField.setBounds(146, 197, 223, 29);

        // 전화번호
        JLabel phoneLabel = new JLabel("전화번호:");
        phoneLabel.setBounds(48, 248, 185, 52);
        phoneLabel.setFont(new Font("돋움", Font.BOLD, 14));
        JTextField phoneField = new JTextField(20);
        phoneField.setBounds(146, 260, 223, 29);

        // 그룹 선택 ComboBox (관리자, 주방, 카운터, 알바생)
        JLabel groupLabel = new JLabel("그룹 선택:");
        groupLabel.setBounds(48, 310, 185, 52);
        groupLabel.setFont(new Font("돋움", Font.BOLD, 14));
        String[] groups = { "관리자", "주방", "카운터", "알바생" };
        JComboBox<String> groupComboBox = new JComboBox<>(groups);
        groupComboBox.setBounds(146, 322, 223, 29);

        // 직책 선택 ComboBox (점장, 매니저, 오전 알바, 오후 알바, 사장)
        JLabel positionLabel = new JLabel("직책 선택:");
        positionLabel.setBounds(48, 372, 185, 52);
        positionLabel.setFont(new Font("돋움", Font.BOLD, 14));
        String[] positions = { "점장", "매니저", "오전 알바", "오후 알바", "사장" };
        JComboBox<String> positionComboBox = new JComboBox<>(positions);
        positionComboBox.setBounds(146, 384, 223, 29);

        // 회원가입 버튼
        JButton signUpButton = new JButton("회원가입 완료");
        signUpButton.setBounds(146, 478, 190, 41);

     // 아이디 중복 확인 버튼
        JButton checkIdButton = new JButton("아이디 중복 확인");
        checkIdButton.setFont(new Font("굴림", Font.BOLD, 12));
        checkIdButton.setBounds(381, 22, 150, 29);

        // 버튼 클릭 시 아이디 중복 확인 동작 처리
        checkIdButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String employeeIdValue = idField.getText().trim();  // 입력된 아이디 값 (공백 제거)

                // 아이디가 비어 있으면 경고 메시지 출력
                if (employeeIdValue.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "아이디를 입력해 주세요.", "아이디 입력 오류", JOptionPane.ERROR_MESSAGE);
                    return; // 아이디가 비어 있으면 중복 확인을 하지 않음
                }

                // 아이디 중복 확인
                if (isIdDuplicate(employeeIdValue)) {
                    JOptionPane.showMessageDialog(frame, "아이디가 이미 존재합니다.", "중복 확인", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "사용 가능한 아이디입니다.", "중복 확인", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
            

        // 버튼 클릭 시 회원가입 처리
        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 입력된 값 가져오기
                String employeeIdValue = idField.getText();
                String employeePassword = new String(passwordField.getPassword());
                String employeeName = nameField.getText();
                String employeeEmail = emailField.getText();
                String employeePhone = phoneField.getText();
                String selectedGroup = (String) groupComboBox.getSelectedItem();
                String selectedPosition = (String) positionComboBox.getSelectedItem();

                // 그룹 ID와 직책 ID 매핑
                int groupId = getGroupId(selectedGroup);
                int positionId = getPositionId(selectedPosition);

                // DB에 데이터 삽입
                try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "basic", "1234")) {
                    String insertSql = "INSERT INTO employees (employee_name, employee_email, employee_phone, group_id, position_id, employee_id_value, employee_password) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)";

                    try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                        pstmt.setString(1, employeeName);
                        pstmt.setString(2, employeeEmail);
                        pstmt.setString(3, employeePhone);
                        pstmt.setInt(4, groupId);
                        pstmt.setInt(5, positionId);
                        pstmt.setString(6, employeeIdValue);
                        pstmt.setString(7, employeePassword);

                        pstmt.executeUpdate();
                        JOptionPane.showMessageDialog(frame, "회원가입 성공!");
                    }

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "DB 연결 오류: " + ex.getMessage());
                }
            }
        });

        frame.getContentPane().setLayout(null);

        // 컴포넌트 화면에 배치
        frame.getContentPane().add(idLabel);
        frame.getContentPane().add(idField);
        frame.getContentPane().add(passwordLabel);
        frame.getContentPane().add(passwordField);
        frame.getContentPane().add(nameLabel);
        frame.getContentPane().add(nameField);
        frame.getContentPane().add(emailLabel);
        frame.getContentPane().add(emailField);
        frame.getContentPane().add(phoneLabel);
        frame.getContentPane().add(phoneField);
        frame.getContentPane().add(groupLabel);
        frame.getContentPane().add(groupComboBox);
        frame.getContentPane().add(positionLabel);
        frame.getContentPane().add(positionComboBox);
        frame.getContentPane().add(signUpButton);
        frame.getContentPane().add(checkIdButton);

        // 화면 표시
        frame.setVisible(true);
    }

    // 그룹 이름에 맞는 그룹 ID 반환
    private static int getGroupId(String group) {
        switch (group) {
            case "관리자":
                return 1;
            case "주방":
                return 2;
            case "카운터":
                return 3;
            case "알바생":
                return 4;
            default:
                return 0;
        }
    }

    // 직책 이름에 맞는 직책 ID 반환
    private static int getPositionId(String position) {
        switch (position) {
            case "점장":
                return 1;
            case "매니저":
                return 2;
            case "오전 알바":
                return 3;
            case "오후 알바":
                return 4;
            case "사장":
                return 5;
            default:
                return 0;
        }
    }

    // 아이디 중복 체크 메서드
    private static boolean isIdDuplicate(String employeeIdValue) {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "basic", "1234")) {
            String checkSql = "SELECT COUNT(*) FROM employees WHERE employee_id_value = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setString(1, employeeIdValue);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt(1) > 0;  // 아이디가 이미 존재하면 true 반환
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "DB 연결 오류: " + e.getMessage());
            e.printStackTrace();
        }
        return false;  // 아이디가 없으면 false 반환
    }
}
