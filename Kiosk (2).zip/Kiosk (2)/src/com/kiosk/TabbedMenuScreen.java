package com.kiosk;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class TabbedMenuScreen extends JFrame {
   
   private JTable cartTable;
   private JLabel totalLabel; // 총 금액을 표시할 라벨
   private CardLayout cardLayout;
   private JPanel mainPanel;
   private JPanel menuPanel;
   
   public TabbedMenuScreen() {

	   // 기본 패널 생성 (CardLayout 사용)
       mainPanel = new JPanel();
       cardLayout = new CardLayout();
       mainPanel.setLayout(cardLayout);
	   
      // OrderPanel과 PaymentPanel을 mainPanel에 추가
      mainPanel.add(createOrderPanel(), "OrderPanel");


      // 기본 설정
      setTitle("키오스크 메뉴");
      setSize(700, 800);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLayout(new BorderLayout());

      // 1. 상단 컨테이너 설정
      JPanel topPanel = new JPanel();
      JLabel titleLabel = new JLabel("메뉴 선택", SwingConstants.CENTER);
      titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 24));
      topPanel.add(titleLabel);
      add(topPanel, BorderLayout.NORTH); // 상단에 배치
      add(mainPanel);

      // 2. 중앙 컨테이너 설정 (탭)
      JTabbedPane tabbedPane = new JTabbedPane();

      
      List<MenuItem> burgerItems = new ArrayList<>();

      burgerItems.add(new MenuItem("치즈버거", 5000, "images/burger/bur1.jpg"));
      burgerItems.add(new MenuItem("치킨버거", 6000, "images/burger/bur2.jpg"));
      burgerItems.add(new MenuItem("불고기버거", 4000, "images/burger/bur3.jpg"));
      burgerItems.add(new MenuItem("2024버거", 6500, "images/burger/bur4.jpg"));
      burgerItems.add(new MenuItem("새우버거", 5000, "images/burger/bur5.jpg"));
      burgerItems.add(new MenuItem("더블패티버거", 6000, "images/burger/bur6.jpg"));

      JPanel burgerMenuPanel = new MenuPanel(burgerItems, this);
      tabbedPane.addTab("버거", burgerMenuPanel);

      // "버거세트" 탭
      List<MenuItem> setMenuItems = new ArrayList<>();
      setMenuItems.add(new MenuItem("치즈버거 세트", 5000, "images/burger/set1.jpg"));
      setMenuItems.add(new MenuItem("치킨버거 세트", 8000, "images/burger/set2.jpg"));
      setMenuItems.add(new MenuItem("불고기버거 세트", 6000, "images/burger/set3.jpg"));
      setMenuItems.add(new MenuItem("2024 세트", 8500, "images/burger/set4.jpg"));
      setMenuItems.add(new MenuItem("새우버거 세트", 7000, "images/burger/set5.jpg"));
      setMenuItems.add(new MenuItem("더블패티버거 세트", 8000, "images/burger/set6.jpg"));

      JPanel setMenuPanel = new MenuPanel(setMenuItems, this);
      tabbedPane.addTab("버거세트", setMenuPanel);

      // "음료" 탭
      List<MenuItem> drinkItems = new ArrayList<>();
      drinkItems.add(new MenuItem("콜라", 1500, "images/beverage/drink1.jpg"));
      drinkItems.add(new MenuItem("사이다", 1500, "images/beverage/drink2.jpg"));
      drinkItems.add(new MenuItem("오렌지주스", 2000, "images/beverage/drink3.jpg"));
      drinkItems.add(new MenuItem("커피", 2500, "images/beverage/drink4.jpg"));
      drinkItems.add(new MenuItem("밀크쉐이크", 3000, "images/beverage/drink5.jpg"));
      
      drinkItems.add(new MenuItem("물", 2000, "images/beverage/drink6.jpg"));

      JPanel drinkMenuPanel = new MenuPanel(drinkItems, this);
      tabbedPane.addTab("음료", drinkMenuPanel);

      // "사이드" 탭
      List<MenuItem> sideItems = new ArrayList<>();
      sideItems.add(new MenuItem("감자튀김", 2000, "images/사이드/감자튀김.jpg"));
      sideItems.add(new MenuItem("너겟", 2000, "images/사이드/너겟.jpg"));
      sideItems.add(new MenuItem("어니언링", 2500, "images/사이드/어니언링.jpg"));
      sideItems.add(new MenuItem("치즈스틱", 3000, "images/사이드/치즈스틱.jpg"));
      sideItems.add(new MenuItem("샐러드", 4500, "images/사이드/샐러드.jpg"));
      sideItems.add(new MenuItem("핫윙", 3500, "images/사이드/핫윙.jpg"));

      JPanel sideMenuPanel = new MenuPanel(sideItems, this);
      tabbedPane.addTab("사이드", sideMenuPanel);

      // 중앙에 탭을 추가
      JPanel centerPanel = new JPanel();
      centerPanel.setLayout(new BorderLayout());
      centerPanel.add(tabbedPane, BorderLayout.CENTER); // 탭을 중앙에 배치
      
      // 중앙 영역 크기 키우기
      centerPanel.setPreferredSize(new Dimension(500, 500)); // 원하는 크기로 조정 (가로 800, 세로 700)
      add(centerPanel, BorderLayout.CENTER);
      
   // 3. 하단 컨테이너 설정 (장바구니와 결제 버튼)
      JPanel bottomPanel = new JPanel();
      bottomPanel.setLayout(new BorderLayout());
      
      // 장바구니 테이블
      String[] cartColumns = { "메뉴", "가격", "수량" };
      DefaultTableModel cartModel = new DefaultTableModel(cartColumns, 0);
      cartTable = new JTable(cartModel);
      cartTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      cartTable.setDefaultEditor(Object.class, null);
      JScrollPane cartScrollPane = new JScrollPane(cartTable);
      bottomPanel.add(cartScrollPane, BorderLayout.CENTER); // 장바구니 테이블 추가

      // 총 금액 라벨
      totalLabel = new JLabel("총 금액: 0원");
      totalLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));

      // 버튼 패널
      JPanel payPanel = new JPanel();
      payPanel.setLayout(new BorderLayout());
      payPanel.add(totalLabel, BorderLayout.WEST); // 총 금액을 결제 버튼 왼쪽에 배치

      // 버튼들 (수정, 삭제, 결제)
      JButton modifyButton = new JButton("추가");
      JButton deleteButton = new JButton("삭제");
      JButton payButton = new JButton("결제하기");

      // Set button size
      modifyButton.setPreferredSize(new Dimension(120, 40)); // Width: 120, Height: 40
      deleteButton.setPreferredSize(new Dimension(120, 40));
      payButton.setPreferredSize(new Dimension(120, 40)); // Slightly larger button for payment

      // Set font (Example: Font name: "맑은고딕", Style: BOLD, Size: 16)
      Font buttonFont = new Font("맑은고딕", Font.BOLD, 16);
      modifyButton.setFont(buttonFont);
      deleteButton.setFont(buttonFont);
      payButton.setFont(buttonFont);

      // Optional: Adjust the button text color (if needed)
      modifyButton.setForeground(Color.BLACK);
      deleteButton.setForeground(Color.BLACK);
      payButton.setForeground(Color.BLACK);

      // 버튼 클릭 이벤트
      modifyButton.addActionListener(e -> modifyItem());
      deleteButton.addActionListener(e -> deleteItem());
      // 결제 버튼 클릭 이벤트 수정
      payButton.addActionListener(new ActionListener() {
         
         @Override
          public void actionPerformed(ActionEvent e) {
              
             if (isCartEmpty()) {
                 JOptionPane.showMessageDialog(mainPanel, "장바구니가 비어 있습니다. 메뉴를 선택하세요.");
             } else {
            	 Payment payment = new Payment();
            	 payment.setVisible(true);
            	 setVisible( false );
             }
          }
      });


      add(payButton, BorderLayout.SOUTH);
      
      // 버튼들을 패널에 추가
      JPanel buttonPanel = new JPanel();
      buttonPanel.add(modifyButton);
      buttonPanel.add(deleteButton);
      buttonPanel.add(payButton);

      payPanel.add(buttonPanel, BorderLayout.CENTER); // 버튼 패널을 중앙에 배치
      bottomPanel.add(payPanel, BorderLayout.SOUTH); // 결제 버튼 패널 추가

   // 하단 영역 크기 줄이기
      bottomPanel.setPreferredSize(new Dimension(500, 200)); // 하단의 높이를 줄임 (예: 180px로 설정)
      
      add(bottomPanel, BorderLayout.SOUTH); // 하단에 장바구니와 결제 버튼 추가

      // 화면 표시
      setLocationRelativeTo(null);
      setVisible(true);
   }

   private boolean isCartEmpty() {
      // 장바구니에 아이템이 없다면 true, 있으면 false 반환
      return cartTable.getRowCount() == 0;
   }

   private JPanel createOrderPanel() {
      // OrderPanel 생성하는 코드
      JPanel panel = new JPanel();
      // 여기에 메뉴 선택 화면 구현...
      return panel;
   }

   

   // 장바구니에서 항목 수정
   private void modifyItem() {
      int selectedRow = cartTable.getSelectedRow();
      if (selectedRow != -1) {
         DefaultTableModel model = (DefaultTableModel) cartTable.getModel();

         int quantity = (int) model.getValueAt(selectedRow, 2);

         // 수량 증가
         quantity++;

         model.setValueAt(quantity, selectedRow, 2); // 수량 증가

         updateTotalPrice();
      } else {
         JOptionPane.showMessageDialog(this, "수정할 항목을 선택해주세요.");
      }
   }

   // 장바구니에서 항목 삭제
   private void deleteItem() {
      int selectedRow = cartTable.getSelectedRow();
      if (selectedRow != -1) {
         DefaultTableModel model = (DefaultTableModel) cartTable.getModel();
         int quantity = (int) cartTable.getValueAt(selectedRow, 2); // 수량

         quantity--;

         cartTable.setValueAt(quantity, selectedRow, 2);

         if (quantity == 0) {
            model.removeRow(selectedRow); // 선택된 행 삭제
         }
         updateTotalPrice();
      } else {
         JOptionPane.showMessageDialog(this, "삭제할 항목을 선택해주세요.");
      }
   }

   // TabbedMenuScreen 클래스 내에 addToCart 메서드 추가
   public void addToCart(String itemName, int itemPrice) {
      DefaultTableModel model = (DefaultTableModel) cartTable.getModel();

      // 이미 항목이 장바구니에 있는지 확인
      boolean itemExists = false;
      for (int i = 0; i < model.getRowCount(); i++) {
         if (model.getValueAt(i, 0).equals(itemName)) {
            // 수량 증가
            int currentQuantity = (int) model.getValueAt(i, 2);
            model.setValueAt(currentQuantity + 1, i, 2);
            itemExists = true;
            break;
         }
      }

      // 항목이 없으면 새로 추가
      if (!itemExists) {
         model.addRow(new Object[] { itemName, itemPrice, 1 });
      }

      updateTotalPrice();
   }

   // 총 금액 업데이트
   private void updateTotalPrice() {
      int rowCount = cartTable.getRowCount();
      int total = 0;
      for (int i = 0; i < rowCount; i++) {
         int price = (int) cartTable.getValueAt(i, 1);
         int quantity = (int) cartTable.getValueAt(i, 2);
         total += price * quantity;
      }
      totalLabel.setText("총 금액: " + total + "원");
   }

   public static void main(String[] args) {
      new TabbedMenuScreen();
   }
}