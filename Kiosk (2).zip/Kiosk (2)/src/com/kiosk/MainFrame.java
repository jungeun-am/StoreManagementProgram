package com.kiosk;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        // 기본 설정
        setTitle("메인 화면");
        setSize(700,800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        getContentPane().setBackground(Color.BLACK); 
        
        // 타이틀 설정 (상단)
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        topPanel.setBackground(Color.BLACK);  // 상단 배경 검정색 설정
        
        JLabel titleLabel = new JLabel("키오스크 시스템", SwingConstants.CENTER);
        titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);  // 글자 색을 흰색으로 설정
        topPanel.add(titleLabel);

        // 이미지 추가 (중앙에 위치)
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(new FlowLayout());
        middlePanel.setBackground(Color.BLACK);  // 중간 배경도 검정색으로 설정

        // 이미지를 로드하고 JLabel에 설정
        ImageIcon kioskImage = new ImageIcon("images/burger/back_burger.jpg");  // 이미지 경로 수정
        Image image = kioskImage.getImage(); // 이미지 객체로 변환
        Image scaledImage = image.getScaledInstance(800, 900, Image.SCALE_SMOOTH); // 이미지 크기 조정
        ImageIcon scaledImageIcon = new ImageIcon(scaledImage); // 크기가 조정된 이미지를 ImageIcon으로 변환
        
        JLabel imageLabel = new JLabel(scaledImageIcon); // 크기가 조정된 이미지를 JLabel에 설정
        middlePanel.add(imageLabel); // middlePanel에 이미지 추가


        // 하단 패널 설정 (하단)
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout());
        bottomPanel.setBackground(Color.BLACK);  // 하단 배경 검정색 설정
        
        // 메뉴 버튼 설정 (하단에 배치)
        JButton menuButton = new JButton("주문하러 가기");
        menuButton.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        menuButton.setForeground(Color.WHITE);  // 버튼 텍스트를 흰색으로 설정
        menuButton.setBackground(Color.BLACK);  // 버튼 배경을 검정색으로 설정
        
        menuButton.addActionListener(e -> openMenuScreen()); // 메뉴 화면으로 전환
        bottomPanel.add(menuButton);
        

        
        // 각 패널을 BorderLayout에 추가
        add(topPanel, BorderLayout.NORTH);
        add(middlePanel, BorderLayout.CENTER);  
        add(bottomPanel, BorderLayout.SOUTH);

        // 화면 표시
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void openMenuScreen() {
        this.setVisible(false);
        this.dispose();
        
        // 메뉴 화면으로 이동
        new TabbedMenuScreen(); // 여기에 실제 메뉴 화면을 호출
    }
    public void ChangeOrder(String selectedMenu) {
      
   }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}
