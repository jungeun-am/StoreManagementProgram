package com.kiosk;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        // 기본 JFrame 설정
        JFrame frame = new JFrame("메인 화면");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // CardLayout을 사용하여 화면 전환 설정
        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);

        // 1. 장바구니 화면 패널 생성
        JPanel cartPanel = new JPanel(new BorderLayout());
        String[] columnNames = {"아이템", "수량", "가격"};
        Object[][] rowData = {
            {"아이템1", 1, 5000},
            {"아이템2", 2, 15000},
            {"아이템3", 1, 7000}
        };
        DefaultTableModel model = new DefaultTableModel(rowData, columnNames);
        JTable cartTable = new JTable(model);

        // 장바구니 테이블 추가
        cartPanel.add(new JScrollPane(cartTable), BorderLayout.CENTER);

        // 결제 버튼 추가
        JButton payButton = new JButton("결제하기");
        cartPanel.add(payButton, BorderLayout.SOUTH);

        // 2. 결제 화면 패널 생성
//        Payment paymentScreen = new Payment();  // cartTable을 전달하여 payment1 화면 생성
        
//        JPanel paymentPanel = paymentScreen.getPanel(); // payment1에서 반환된 JPanel을 가져옴

        // 화면 전환을 위한 버튼 액션 리스너
        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isCartEmpty(cartTable)) {
                    JOptionPane.showMessageDialog(cartPanel, "장바구니가 비어 있습니다. 메뉴를 선택하세요.");
                } else {
                    // 결제 화면으로 전환
                    cardLayout.show(mainPanel, "PaymentScreen");
                    System.out.println("결제 버튼 클릭됨");
                }
            }
        });

        // mainPanel에 장바구니 화면 패널 추가
        mainPanel.add(cartPanel, "CartScreen");
        // mainPanel에 결제 화면 패널 추가
//        mainPanel.add(paymentScreen, "PaymentScreen");

        // 카드 레이아웃에서 장바구니 화면을 기본 화면으로 설정
        cardLayout.show(mainPanel, "CartScreen");

        // JFrame에 mainPanel 추가
        frame.add(mainPanel);
        frame.setVisible(true);
    }

    // 장바구니가 비어있는지 체크하는 메서드
    private static boolean isCartEmpty(JTable cartTable) {
        // JTable에서 데이터가 비어 있는지 확인 (모든 행이 비어있으면 빈 장바구니로 간주)
        return cartTable.getRowCount() == 0;
    }
}
