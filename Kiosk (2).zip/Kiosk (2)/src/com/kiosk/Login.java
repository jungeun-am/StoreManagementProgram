package com.kiosk;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends JFrame {
	
	private Image backgroundImage;
    public Login() {
        // JFrame 설정	
        setTitle("로그인 화면");
        setSize(700, 800);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        // 전체 패널 설정
        setLayout(new BorderLayout());

        
        // 상단 패널
        JPanel topPanel = new JPanel();
        JLabel title = new JLabel("로그인");
        title.setFont(new Font("맑은고딕", Font.BOLD, 16)); // 제목 폰트 크기 설정
        topPanel.add(title);
        topPanel.setPreferredSize(new Dimension(300, 50));

        // 중앙 패널
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout()); // 더 정교한 배치를 위해 GridBagLayout 사용
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // 간격 설정

        JLabel jl1 = new JLabel("이름:");
        jl1.setFont(new Font("맑은고딕", Font.BOLD, 17)); // 폰트 크기 조정
        JTextField id = new JTextField(10);
        JLabel jl2 = new JLabel("비밀번호:");
        jl2.setFont(new Font("맑은고딕", Font.BOLD, 17)); // 폰트 크기 조정

        JPasswordField password = new JPasswordField(10);

        // GridBagConstraints를 사용해 각 컴포넌트 배치
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        centerPanel.add(jl1, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        centerPanel.add(id, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        centerPanel.add(jl2, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        centerPanel.add(password, gbc);

        // 하단 패널
        JPanel bottomPanel = new JPanel();
        JButton loginButton = new JButton("로그인");
        JButton signUpButton = new JButton("직원등록");

        // 직원등록 버튼 클릭 시 이벤트 처리
        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // 로그인 창을 닫기
                SignUp signUp = new SignUp(); // 직원등록 화면 열기
                
                signUp.setVisible(true);
            }
        });

        // 로그인 버튼 클릭 시 이벤트 처리
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userId = id.getText();
                String userPassword = new String(password.getPassword());

                // DB에서 사용자 정보 확인
                if (validateLogin(userId, userPassword)) {
                    new MainFrame(); // 로그인 성공 시 Main 화면 열기
                    dispose(); // 로그인 창 닫기
                } else {
                    // 로그인 실패 시 오류 메시지
                    JOptionPane.showMessageDialog(Login.this, "아이디나 비밀번호가 올바르지 않습니다.", "로그인 실패",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        bottomPanel.add(loginButton);
        bottomPanel.add(signUpButton);
        bottomPanel.setPreferredSize(new Dimension(300, 50));

        
        // 각각의 패널을 프레임에 배치
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // JTextField와 JPasswordField에 ENTER 키 이벤트 추가
        ActionListener enterListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginButton.doClick(); // 로그인 버튼 클릭 동작
            }
        };

        id.addActionListener(enterListener);
        password.addActionListener(enterListener);

        // JFrame 보이기
        setVisible(true);
    }

    // DB에서 사용자 정보 검증
    private boolean validateLogin(String userId, String userPassword) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe"; // DB URL
        String dbUser = "System"; // DB 사용자명
        String dbPassword = "1234"; // DB 비밀번호

        // 사용자 인증 쿼리
        String query = "SELECT * FROM EMPLOYEES WHERE NAME = ? AND PASSWORD_HASH = ?";

        // 입력된 비밀번호 해시화
        String hashedPassword = hashPassword(userPassword);

        try (Connection conn = DriverManager.getConnection(url, dbUser, dbPassword);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // 쿼리 파라미터 설정
            stmt.setString(1, userId); // 사용자 이름
            stmt.setString(2, hashedPassword); // 해시화된 비밀번호

            // 쿼리 실행
            ResultSet rs = stmt.executeQuery();

            // 결과가 있으면 로그인 성공
            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 비밀번호 해시화 함수 (SHA-256 사용)
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        new Login(); // 로그인 창 열기
    }
}
