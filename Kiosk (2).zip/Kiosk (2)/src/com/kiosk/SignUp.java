package com.kiosk;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import db.DBConnection; // DBConnection 클래스 임포트

public class SignUp extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JPasswordField passwordField;
    private JPasswordField passwordField_1;
    private JTextField idField; // 아이디 입력 필드
    private boolean isIdChecked = false;  // 아이디 중복확인 여부를 저장하는 변수

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SignUp frame = new SignUp();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SignUp() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 800);
        
     // Panel을 사용자 정의 클래스로 생성
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);  // 기존 컴포넌트도 그리기
                // 배경 이미지 경로
                ImageIcon icon = new ImageIcon("images/etc/back.jpg");  // 실제 이미지 경로로 변경
                Image img = icon.getImage();  // ImageIcon을 Image로 변환
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);  // 이미지 그리기
            }
        };
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // 관리자 등록 라벨
        JLabel lblNewLabel = new JLabel("관리자 등록");
        lblNewLabel.setFont(new Font("굴림", Font.BOLD, 25));
        lblNewLabel.setBounds(301, 205, 150, 50);
        
        contentPane.add(lblNewLabel);

     // 아이디 라벨 앞에 * 표시
        JLabel x1 = new JLabel("*");
        x1.setForeground(Color.RED);
        x1.setBounds(148, 258, 16, 15);  // "아이디" 라벨 앞에 위치
        contentPane.add(x1);
        
        // 아이디 입력 라벨 및 필드
        JLabel idLabel = new JLabel("아이디");
        idLabel.setBounds(186, 258, 42, 15);
        contentPane.add(idLabel);
        idField = new JTextField();
        idField.setColumns(10);
        idField.setBounds(324, 255, 116, 21);
        contentPane.add(idField);
        
     // 아이디 입력 길이 제한 (최대 15자리) 및 영문, 숫자만 입력
        idField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                // 입력된 키값을 가져옴
                char c = e.getKeyChar();

                // 영문자 (a-z, A-Z)와 숫자 (0-9)만 허용
                if (!(Character.isLetterOrDigit(c))) {
                    e.consume();  // 영문자와 숫자 외의 문자는 입력되지 않도록 처리
                }

                // 텍스트 필드에 입력된 내용의 길이가 15자 이상이면 더 이상 입력되지 않도록 처리
                if (idField.getText().length() >= 15) {
                    e.consume();  // 15자 이상이면 입력되지 않음
                }
            }
        });

        // 아이디 중복 확인 버튼
        JButton idCheckButton = new JButton("아이디 중복 확인");
        idCheckButton.setBounds(454, 254, 150, 23);
        contentPane.add(idCheckButton);
        
        
     // 이름 라벨 앞에 * 표시
        JLabel x2 = new JLabel("*");
        x2.setForeground(Color.RED);
        x2.setBounds(148, 300, 16, 15);  // "이름" 라벨 앞에 더 가깝게 위치
        contentPane.add(x2);


        // 이름 입력 라벨 및 필드
        JLabel Name_JL = new JLabel("이름");
        Name_JL.setBounds(186, 300, 42, 15);
        contentPane.add(Name_JL);
        textField = new JTextField();
        textField.setColumns(10);
        textField.setBounds(324, 293, 116, 21);
        contentPane.add(textField);
        
     // 비밀번호 라벨 앞에 * 표시
        JLabel x3 = new JLabel("*");
        x3.setForeground(Color.RED);
        x3.setBounds(148, 342, 16, 15);  // "비밀번호" 라벨 앞에 더 가깝게 위치
        contentPane.add(x3);


        // 비밀번호 입력 라벨 및 필드
        JLabel Pwd_JL = new JLabel("비밀번호");
        Pwd_JL.setBounds(186, 342, 57, 15);
        contentPane.add(Pwd_JL);
        passwordField = new JPasswordField();
        passwordField.setBounds(324, 339, 116, 21);
        contentPane.add(passwordField);
        
        JLabel Caution_LB2 = new JLabel("※ 숫자 4자리 입력");
        Caution_LB2.setForeground(new Color(255, 128, 128));
        Caution_LB2.setFont(new Font("굴림", Font.PLAIN, 11));
        Caution_LB2.setBounds(454, 343, 150, 15);
        contentPane.add(Caution_LB2);

     // 비밀번호 확인 라벨 앞에 * 표시
        JLabel x4 = new JLabel("*");
        x4.setForeground(Color.RED);
        x4.setBounds(148, 385, 16, 15);  // "비밀번호 확인" 라벨 앞에 더 가깝게 위치
        contentPane.add(x4);
        
        // 비밀번호 확인 입력 라벨 및 필드
        JLabel PwdCheck_JL = new JLabel("비밀번호 확인");
        PwdCheck_JL.setBounds(187, 385, 89, 15);
        contentPane.add(PwdCheck_JL);
        passwordField_1 = new JPasswordField();
        passwordField_1.setBounds(324, 381, 116, 21);
        contentPane.add(passwordField_1);
        JLabel Caution_LB_3 = new JLabel("※ 숫자 4자리 입력");
        Caution_LB_3.setForeground(new Color(255, 128, 128));
        Caution_LB_3.setFont(new Font("굴림", Font.PLAIN, 11));
        Caution_LB_3.setBounds(454, 385, 150, 15);
        contentPane.add(Caution_LB_3);

     // 직책 라벨 앞에 * 표시
        JLabel x5 = new JLabel("*");
        x5.setForeground(Color.RED);
        x5.setBounds(148, 428, 16, 15);  // "직책" 라벨 앞에 더 가깝게 위치
        contentPane.add(x5);
        
        // 직책 선택 드롭다운
        JLabel Phone_JL = new JLabel("직책");
        Phone_JL.setBounds(186, 428, 57, 15);
        contentPane.add(Phone_JL);
        JComboBox<String> position = new JComboBox<String>();
        position.setBackground(Color.WHITE);
        position.setBounds(324, 424, 116, 23);
        position.addItem("직책을 선택하세요");
        position.addItem("크루");
        position.addItem("리더");
        position.addItem("매니저");
        contentPane.add(position);

        // 직원 등록 완료 버튼
        JButton SignUp_BT = new JButton("직원 등록 완료");
        SignUp_BT.setForeground(Color.BLACK);
        SignUp_BT.setFont(new Font("굴림", Font.BOLD, 20));
        SignUp_BT.setBackground(Color.WHITE);
        SignUp_BT.setBounds(279, 578, 202, 50);
        contentPane.add(SignUp_BT);
        
        

        // 비밀번호 숫자만 입력 가능하게 KeyListener
        passwordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();  // 숫자가 아닌 문자는 입력되지 않도록 처리
                }
                if (passwordField.getPassword().length >= 4) {
                    e.consume();  // 4자리가 넘으면 더 이상 입력되지 않도록 처리
                }
            }
        });

        passwordField_1.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();  // 숫자가 아닌 문자는 입력되지 않도록 처리
                }
                if (passwordField_1.getPassword().length >= 4) {
                    e.consume();  // 4자리가 넘으면 더 이상 입력되지 않도록 처리
                }
            }
        });

        // 아이디 중복 확인 버튼 클릭 이벤트
        idCheckButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText().trim();
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.");
                    return;
                }
                // 아이디가 영문만 포함하는지 확인
                if (!isValidId(id)) {
                    JOptionPane.showMessageDialog(null, "아이디는 영문자와 숫자만 사용 가능합니다.");
                    return;
                }
                // 아이디 중복 체크
                if (isIdDuplicate(id)) {
                    JOptionPane.showMessageDialog(null, "이미 사용 중인 아이디입니다.");
                } else {
                    JOptionPane.showMessageDialog(null, "사용 가능한 아이디입니다.");
                    isIdChecked = true;  // 아이디 중복 확인 완료
                }
            }
        });

        // 회원가입 완료 버튼 클릭 시
        SignUp_BT.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                String password = new String(passwordField.getPassword());
                String passwordCheck = new String(passwordField_1.getPassword());
                String role = (String) position.getSelectedItem();

                // 필수 입력 항목 체크
                if (name.isEmpty() || password.isEmpty() || passwordCheck.isEmpty() || role.equals("직책을 선택하세요")) {
                    JOptionPane.showMessageDialog(null, "모든 항목을 입력해 주세요.");
                    return;
                }

                // 비밀번호 확인
                if (!password.equals(passwordCheck)) {
                    JOptionPane.showMessageDialog(null, "비밀번호가 일치하지 않습니다.");
                    return;
                }

                // 비밀번호 길이 확인
                if (password.length() != 4) {
                    JOptionPane.showMessageDialog(null, "비밀번호는 4자리여야 합니다.");
                    return;
                }

                // 아이디 중복 확인 여부 체크
                if (!isIdChecked) {
                    JOptionPane.showMessageDialog(null, "아이디 중복 확인을 해주세요.");
                    return;
                }

                // 직책 번호 설정
                int positionNo = 0;
                if (role.equals("크루")) {
                    positionNo = 1;
                } else if (role.equals("리더")) {
                    positionNo = 2;
                } else if (role.equals("매니저")) {
                    positionNo = 3;
                }

                // 사용자 데이터베이스에 저장
                saveUserToDatabase(idField.getText(), name, password, positionNo);
            }
        });
    }

 // 아이디가 영문자와 숫자만 포함되도록 체크하는 메서드
    private boolean isValidId(String id) {
        return id.matches("^[a-zA-Z0-9]+$");  // 영문자와 숫자만 허용
    }

    // 비밀번호 해시 처리
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 아이디 중복 확인 메서드
    private boolean isIdDuplicate(String id) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT COUNT(*) FROM EMPLOYEES WHERE USERNAME = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 사용자 정보를 데이터베이스에 저장
    private void saveUserToDatabase(String id, String name, String password, int positionNo) {
        try (Connection conn = DBConnection.getConnection()) {
        	 String sql = "INSERT INTO EMPLOYEES (USERNAME, NAME, PASSWORD_HASH, ROLE_ID) " +
                     "VALUES (?, ?, ?, ?)";  // 시퀀스를 통한 자동 증가

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setString(3, hashPassword(password));
            stmt.setInt(4, positionNo);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.");
                // 직원 등록 성공 시 Login 화면을 띄운다.

                dispose();  // 현재 SignUp 창을 닫는다.

                Login loginFrame = new Login();  // Login 창을 생성
                loginFrame.setVisible(true);
                
            } else {
                JOptionPane.showMessageDialog(this, "직원등록 실패. 다시 시도해주세요.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "데이터베이스 연결 실패");
        }
    }
}
