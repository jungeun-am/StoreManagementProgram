/*package com.kiosk;

import java.awt.*;
import javax.swing.*;

public class ChangeOrder extends JFrame {

    public ChangeOrder() {
        // 프레임 기본 설정
        setTitle("메뉴 변경");
        setSize(600, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 상단 컨테이너: 음료 메뉴
        JPanel beverageContainer = new JPanel();
        beverageContainer.setLayout(new BorderLayout());
        beverageContainer.add(createMenuPanel("음료 메뉴",
                new String[]{"오렌지주스", "커피", "밀크쉐이크"},
                new String[]{"images/beverage/오렌지주스.jpg", "images/beverage/커피.jpg", "images/beverage/밀크쉐이크.jpg"},
                1, 3), BorderLayout.CENTER);

        // 중간 컨테이너: 사이드 메뉴
        JPanel sideContainer = new JPanel();
        sideContainer.setLayout(new BorderLayout());
        sideContainer.add(createMenuPanel("사이드 메뉴",
                new String[]{"너겟", "어니언링", "치즈스틱", "샐러드", "핫윙"},
                new String[]{"images/사이드/너겟.jpg", "images/사이드/어니언링.jpg",
                             "images/사이드/치즈스틱.jpg", "images/사이드/샐러드.jpg",
                             "images/사이드/핫윙.jpg"},
                2, 3), BorderLayout.CENTER);

        // 하단 버튼 패널 설정
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));

        // '결제' 버튼
        JButton orderButton = new JButton("결제");
        orderButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        orderButton.setPreferredSize(new Dimension(120, 40));
        orderButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "주문이 완료되었습니다.");
            dispose(); // 창 닫기
        });

        // '취소' 버튼
        JButton cancelButton = new JButton("취소");
        cancelButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        cancelButton.setPreferredSize(new Dimension(120, 40));
        cancelButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "주문을 취소했습니다.");
            dispose(); // 창 닫기
        });

        // 버튼 추가
        buttonPanel.add(orderButton);
        buttonPanel.add(cancelButton);

        // 하단 버튼 패널을 추가
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);

        // 각 컨테이너를 프레임에 추가
        add(beverageContainer, BorderLayout.NORTH);
        add(sideContainer, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // 크기 고정 및 보이기 설정
        setResizable(false);
        setVisible(true);
    }

    private JPanel createMenuPanel(String title, String[] itemNames, String[] imagePaths, int rows, int cols) {
        // 메뉴 패널 생성
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BorderLayout());

        // 제목 표시
        JLabel titleLabel = new JLabel(title, JLabel.CENTER);
        titleLabel.setFont(new Font("맑은고딕", Font.BOLD, 20));
        menuPanel.add(titleLabel, BorderLayout.NORTH);

        // 메뉴 아이템 패널
        JPanel itemPanel = new JPanel();
        itemPanel.setLayout(new GridLayout(rows, cols, 10, 10));

        // 라디오 버튼 그룹 생성
        ButtonGroup buttonGroup = new ButtonGroup();

        // 각 메뉴 아이템 추가
        for (int i = 0; i < itemNames.length; i++) {
            JPanel item = new JPanel();
            item.setLayout(new BorderLayout());
            item.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

            // 이미지 추가
            ImageIcon icon = new ImageIcon(imagePaths[i]);
            Image scaledImage = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
            item.add(imageLabel, BorderLayout.CENTER);

            // 라디오 버튼 추가
            JRadioButton radioButton = new JRadioButton(itemNames[i]);
            radioButton.setFont(new Font("맑은고딕", Font.BOLD, 16));
            radioButton.setHorizontalAlignment(SwingConstants.CENTER);
            buttonGroup.add(radioButton);
            item.add(radioButton, BorderLayout.SOUTH);

            // 메뉴 아이템 패널에 추가
            itemPanel.add(item);
        }

        menuPanel.add(itemPanel, BorderLayout.CENTER);
        return menuPanel;
    }

    public static void main(String[] args) {
        new ChangeOrder();
    }
}

*/
