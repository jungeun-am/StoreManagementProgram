package com.kiosk;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MenuPanel extends JPanel {

    public MenuPanel(List<MenuItem> menuItems, TabbedMenuScreen parentFrame) {
        setLayout(new GridLayout(2, 3, 10, 10)); // 2행 3열 레이아웃
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(Color.LIGHT_GRAY);

        for (MenuItem item : menuItems) {
            JButton menuButton = new JButton("<html><center>" + item.getName() + "<br>" + item.getPrice() + "원</center></html>");
            menuButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));
            menuButton.setHorizontalTextPosition(SwingConstants.CENTER);
            menuButton.setVerticalTextPosition(SwingConstants.BOTTOM);
            menuButton.setPreferredSize(new Dimension(180, 200));

            // 이미지 추가 및 크기 조정
            if (item.getImagePath() != null) {
                ImageIcon icon = new ImageIcon(item.getImagePath());
                Image scaledImage = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                menuButton.setIcon(new ImageIcon(scaledImage));
            }

            menuButton.setBackground(Color.WHITE);
            menuButton.setOpaque(true);

            // 버튼 클릭 시 동작 설정
            menuButton.addActionListener(e -> {
               
                parentFrame.addToCart(item.getName(), item.getPrice()); // 장바구니에 추가

                /* 버거 세트 A~F만 팝업 창 띄우기
                if (item.getName().matches("버거 세트 [A-F]")) {
                    new ChangeOrder(); // ChangeOrder 팝업 창 띄우기
                }
                */
                
            });

            add(menuButton); // 버튼을 패널에 추가
        }
    }
    
    
    
    
}
