// MenuItem 클래스 (예시)
package com.kiosk;

// MenuItem 클래스
class MenuItem {
    private String name;
    private int price;
    private String imagePath;

    public MenuItem(String name, int price, String imagePath) {
        this.name = name;
        this.price = price;
        this.imagePath = imagePath;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public String getImagePath() {
        return imagePath;
    }
}
