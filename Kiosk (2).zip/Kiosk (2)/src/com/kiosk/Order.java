package com.kiosk;

public class Order {
    private int orderId;
    private String productName;
    private int quantity;
    private int price;

    public Order(int orderId, String productName, int quantity, int price) {
        this.orderId = orderId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public int getOrderId() {
        return orderId;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPrice() {
        return price;
    }

    // 주문 금액 계산
    public int getAmount() {
        return this.quantity * this.price;
    }

	public int getMenuNo() {
		// TODO Auto-generated method stub
		return 0;
	}
}
