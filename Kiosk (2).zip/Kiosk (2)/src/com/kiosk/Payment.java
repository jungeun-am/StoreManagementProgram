package com.kiosk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Payment extends JFrame{
    private JPanel panel;
    private JPanel paymentButtonsPanel;
    private JButton confirmPaymentButton;
    private JButton backButton;
    private JButton cancelButton;
    private String selectedPaymentMethod = null; // 결제 수단을 추적
    private Object[][] data; // 결제 정보를 저장하는 데이터 배열

    public Payment() {
        // JFrame 설정
        setTitle("결제 화면");
        setSize(700, 800);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 임시 데이터 배열 (예: 상품명, 수량, 가격)
        // 예를 들어 데이터 배열이 변경되었을 때
        data = new Object[][] {
            {"햄버거", 3, 12000},  // 수량과 가격이 변경된 예시
            {"콜라", 2, 3000}
        };

        panel = new JPanel(new BorderLayout());

        // 상단에 빈 공간 추가
        JPanel topPanel = new JPanel();
        topPanel.setPreferredSize(new Dimension(800, 120)); // 상단 패널 높이 설정
        panel.add(topPanel, BorderLayout.NORTH);

        // 결제 수단 버튼 추가
        paymentButtonsPanel = new JPanel(new FlowLayout());
        addPaymentMethodButton("신용카드", "images/pay/credit.jpg");
        addPaymentMethodButton("카카오페이", "images/pay/kakaopay.jpg");
        addPaymentMethodButton("네이버페이", "images/pay/naverpay.jpg");
        addPaymentMethodButton("토스", "images/pay/toss.jpg");
        panel.add(paymentButtonsPanel, BorderLayout.CENTER);

        // 하단 패널 (결제 버튼들)
        JPanel bottomPanel = new JPanel(new FlowLayout());

        // 결제 버튼
        confirmPaymentButton = new JButton("결제하기");
        confirmPaymentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (selectedPaymentMethod == null) {
                    JOptionPane.showMessageDialog(panel, "결제 수단을 선택해주세요.");
                } else {
                    processPayment();
                }
            }
        });
        bottomPanel.add(confirmPaymentButton);

        // 뒤로가기 버튼
        backButton = new JButton("결제취소");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainFrame main = new MainFrame();
                main.setVisible(true);
                dispose();
            }
        });
        bottomPanel.add(backButton);

        // 결제 수단 초기화 버튼
        cancelButton = new JButton("결제 수단 초기화");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelPayment(); // 결제 수단 초기화
            }
        });
        bottomPanel.add(cancelButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);
        this.add(panel);
        setVisible(true);
    }

    private void addPaymentMethodButton(String methodName, String imageFile) {
        JButton paymentButton = new JButton(methodName); // 버튼 생성

        // 이미지 아이콘을 일정 크기로 맞추기 위해 ImageIcon을 생성하고 크기 조정
        ImageIcon icon = new ImageIcon(imageFile); // 이미지 경로로 ImageIcon 객체 생성
        Image image = icon.getImage(); // 원본 이미지를 가져옴
        int width = 150;  // 버튼의 최대 너비
        int height = 80; // 버튼의 최대 높이
        
        // 이미지 크기 조정 (최대 너비와 최대 높이에 맞게 조정)
        Image scaledImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH); // 크기 조정
        ImageIcon scaledIcon = new ImageIcon(scaledImage); // 크기 조정된 이미지를 새로운 ImageIcon으로 설정
        
        paymentButton.setIcon(scaledIcon); // 크기 조정된 이미지를 아이콘으로 설정
        paymentButton.setText(methodName); // 버튼 텍스트 설정
        paymentButton.setHorizontalTextPosition(SwingConstants.CENTER); // 텍스트가 버튼 아래에 위치하도록 설정
        paymentButton.setVerticalTextPosition(SwingConstants.BOTTOM); // 텍스트가 버튼 아래에 위치하도록 설정
        paymentButton.setPreferredSize(new Dimension(width, height + 30)); // 버튼 크기 (이미지 + 텍스트 영역)

        // 테두리 없애기
        paymentButton.setBorderPainted(false); // 테두리 그리지 않음
        paymentButton.setContentAreaFilled(true); // 배경을 채우도록 설정

        // 버튼 클릭 시 동작
        paymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 선택된 결제 수단 표시
                selectedPaymentMethod = methodName; // 선택된 결제 수단 업데이트

                // 모든 버튼의 배경색 초기화
                for (Component comp : paymentButtonsPanel.getComponents()) {
                    if (comp instanceof JButton) {
                        comp.setBackground(null); // 기본 배경색으로 설정
                    }
                }

                // 클릭된 버튼의 배경색을 변경
                paymentButton.setBackground(Color.YELLOW); // 색상을 설정 (선택된 버튼에 색상 변경)
            }
        });
        
        paymentButtonsPanel.add(paymentButton); // 패널에 버튼 추가
    }

    // 결제 처리 (DB 연결 및 결제 진행)
    private void processPayment() {
        // DB 연결 및 결제 로직 추가
        System.out.println("결제 진행: " + selectedPaymentMethod);
        JOptionPane.showMessageDialog(panel, "결제가 완료되었습니다.");
        this.dispose();
        MainFrame tempMain = new MainFrame();
        tempMain.setVisible(true);
    }

    // 결제 수단 초기화
    private void cancelPayment() {
        selectedPaymentMethod = null;
        // 모든 버튼의 배경색을 원래 색상으로 되돌리기
        for (Component comp : paymentButtonsPanel.getComponents()) {
            if (comp instanceof JButton) {
                comp.setBackground(null); // 기본 배경색으로 설정
            }
        }
        JOptionPane.showMessageDialog(panel, "결제 수단이 초기화되었습니다.");
    }

    // 실행을 위한 main 메서드 (예시)
    public static void main(String[] args) {
        new Payment();
    }
}
