package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.kiosk.Order;

public class DBConnection {
	
	
  

    // 데이터베이스 연결
    public static Connection getConnection() throws SQLException {
    	
    	  String URL = "jdbc:oracle:thin:@localhost:1521:xe"; // 데이터베이스 URL
    	    String USER = "System"; // 사용자명
    	    String PASSWORD = "1234"; // 비밀번호
    	    
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // 주문 상세 정보 가져오기
    public static Object[][] getOrderDetails(int orderId) {
        String query = "SELECT m.MENU_NM, od.MENU_CNT, m.MENU_PRICE " +
                       "FROM KIOSK_ORDER_DETAIL od " +
                       "JOIN KIOSK_MENU m ON od.MENU_NO = m.MENU_NO " +
                       "WHERE od.ORDER_NO = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setInt(1, orderId);
            ResultSet resultSet = preparedStatement.executeQuery();
            
            List<Object[]> orderDetails = new ArrayList<>();
            while (resultSet.next()) {
                String menuName = resultSet.getString("MENU_NM");
                int quantity = resultSet.getInt("MENU_CNT");
                double price = resultSet.getDouble("MENU_PRICE");
                orderDetails.add(new Object[] { menuName, quantity, price });
            }
            
            return orderDetails.toArray(new Object[0][0]);
        } catch (SQLException e) {
            e.printStackTrace();
            return new Object[0][0]; // 오류 발생 시 빈 배열 반환
        }
    }

    // 결제 수단 목록 가져오기
    public static List<String> getPaymentMethods() {
        String query = "SELECT PAYMENT_METHOD_NAME FROM KIOSK_PAYMENT_METHOD";
        List<String> paymentMethods = new ArrayList<>();
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            
            while (resultSet.next()) {
                paymentMethods.add(resultSet.getString("PAYMENT_METHOD_NAME"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return paymentMethods;
    }

    // 주문 정보 삽입
    public static int insertOrder(double totalPrice) throws SQLException {
        String query = "INSERT INTO KIOSK_ORDER (ORDER_TOTAL_PRICE, ORDER_DATE) VALUES (?, NOW())";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            preparedStatement.setDouble(1, totalPrice);
            int affectedRows = preparedStatement.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1); // 생성된 주문 ID 반환
                    }
                }
            }
            return -1; // 삽입 실패 시 -1 반환
        }
    }

    // 주문 및 결제 정보 삽입
    public static void insertOrderAndPayment(Order[] orders, String paymentMethod, double totalPrice) throws SQLException {
        Connection connection = getConnection();
        try {
            connection.setAutoCommit(false); // 트랜잭션 시작

            // 주문 삽입
            int orderNo = insertOrder(totalPrice);

            // 주문 상세 삽입
            String orderDetailQuery = "INSERT INTO KIOSK_ORDER_DETAIL (ORDER_NO, MENU_NO, MENU_CNT) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(orderDetailQuery)) {
                for (Order order : orders) {
                    preparedStatement.setInt(1, orderNo);
                    preparedStatement.setInt(2, order.getMenuNo()); // 상품 번호 (예: 1, 2, 3)
                    preparedStatement.setInt(3, order.getQuantity()); // 수량
                    preparedStatement.addBatch();
                }
                preparedStatement.executeBatch(); // 일괄 삽입
            }

            // 결제 삽입
            String paymentQuery = "INSERT INTO KIOSK_ORDER_PAYMENT (ORDER_NO, PRICE, PAYMENT_METHOD_NO, ORDER_DATE) " +
                                   "SELECT ?, ?, pm.PAYMENT_METHOD_NO, NOW() FROM KIOSK_PAYMENT_METHOD pm " +
                                   "WHERE pm.PAYMENT_METHOD_NAME = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(paymentQuery)) {
                preparedStatement.setInt(1, orderNo);
                preparedStatement.setDouble(2, totalPrice);
                preparedStatement.setString(3, paymentMethod); // 결제 수단 (예: 신용카드, 카카오페이 등)
                preparedStatement.executeUpdate();
            }

            connection.commit(); // 트랜잭션 커밋
        } catch (SQLException e) {
            connection.rollback(); // 오류 발생 시 롤백
            e.printStackTrace();
        } finally {
            connection.setAutoCommit(true); // 자동 커밋 설정 복구
        }
    }
}
