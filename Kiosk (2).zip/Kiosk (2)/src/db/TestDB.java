package db;

import java.sql.Connection;

public class TestDB {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                System.out.println("DB 연결 성공!");
            }
        } catch (Exception e) {
            System.err.println("DB 연결 테스트 실패: " + e.getMessage());
        }
    }
}